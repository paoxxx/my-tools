import AppIntents
import Foundation

extension Notification.Name {
    static let startRecordingRequested = Notification.Name("startRecordingRequested")
}

/// 给操作按钮和快捷指令用：打开随身记并立刻开始录音
struct StartRecordingIntent: AppIntent {
    static var title: LocalizedStringResource = "开始随身记录音"
    static var description = IntentDescription("打开随身记并马上开始录音")
    static var openAppWhenRun: Bool = true

    @MainActor
    func perform() async throws -> some IntentResult {
        UserDefaults.standard.set(true, forKey: "pendingStart")
        NotificationCenter.default.post(name: .startRecordingRequested, object: nil)
        return .result()
    }
}

struct SuiShenJiShortcuts: AppShortcutsProvider {
    static var appShortcuts: [AppShortcut] {
        AppShortcut(
            intent: StartRecordingIntent(),
            phrases: ["用\(.applicationName)开始录音", "\(.applicationName)开始记录"],
            shortTitle: "开始录音",
            systemImageName: "mic.fill"
        )
    }
}
